Updated 9/23/2020 - Sorry, been too long since an update! New links from from Isiah Jones, Clint Bodungen and a new ICS Security Products Git repo from Rob Rothwell. Hope you Enjoy, please keep them coming!



Many of us in ICS Security get asked fairly often about resources to learn about Industrial Control Systems Security.

A couple months back I started compiling some of the resources that I have used. Then I asked some friends for input and linked to some other really good lists.

Garrett Guinivan added resources, I parsed links and notes posted by Isiah Jones and included links to Robert M. Lee and Dragos, Inc.'s curated reading lists. There is also a trove of Slide Share links provided by Chris Sistrunk. 

If you see some overlap, that typically means those are the gems.

This is by no means exhaustive and I believe it will be a long term work in progress. If you'd like to contribute please message me, together we are stronger.

Lastly, this is my first Git Repo, so any help or recommendations would be appreciated...
